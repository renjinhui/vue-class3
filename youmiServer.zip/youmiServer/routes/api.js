const express = require('express'),
	route = express.Router();

const {
	success,
	getDepartInfo,
	getJobInfo,
	getUserInfo
} = require('../utils/tools');

const {
	writeFile
} = require('../utils/promiseFS');

//=>用户登录
route.post('/login', (req, res) => {
	let {
		account = '',
			password = ''
	} = req.body || {};
	console.log(req.$userDATA)
	const item = req.$userDATA.find(item => {
		return (item.name === account || item.email === account || item.phone === account) && item.password === password;
	});

	if (item) {
		req.session.userID = parseFloat(item.id);
		console.log(req.session.userID)
		req.session.power = getJobInfo(item.jobId, req).power || '';
		let info = req.$userDATA.filter(item=>item.id == req.session.userID)[0]||{};
		res.send(success(true, {
			power: req.session.power,
			...info
		}));
		return;
	}
	res.send(success(false, {
		codeText: 'user name password mismatch!'
	}));
});

//=>检测是否登录
route.get('/login', (req, res) => {
	const userID = req.session.userID;
	console.log('userID',req.session)
	if (userID) {
		res.send(success(true));
		return;
	}
	res.send(success(false, {
		codeText: 'current user is not logged in!'
	}));
});

//=>退出登录
route.get('/signout', (req, res) => {
	req.session.userID = null;
	req.session.power = null;
	res.send(success(true));
});


//=>获取用户详细信息
route.get('/info', (req, res) => {
	let {
		userId = 0
	} = req.query;
	if (parseFloat(userId) === 0) {
		userId = req.session.userID;
	}
	let data = getUserInfo(userId, req);
	if ('name' in data) {
		res.send(success(true, {
			data: {
				id: data.id,
				name: data.name,
				sex: data.sex,
				email: data.email,
				phone: data.phone,
				departmentId: data.departmentId,
				department: getDepartInfo(data.departmentId, req).name,
				jobId: data.jobId,
				job: getJobInfo(data.jobId, req).name,
				desc: data.desc
			}
		}));
		return;
	}
	res.send(success(false, {
		codeText: 'no matching data was found!'
	}));
});

route.get('/banner',(req,res)=>{
	console.log(req.$banner)
	res.send(success(true, {
		data: req.$banner
	}));
})

route.get('/navs',(req,res)=>{
	res.send(success(true, {
		data: req.$navs
	}));
})

route.get('/goods',(req,res)=>{
	res.send(success(true, {
		data: req.$goods
	}));
})
route.get('/goodsInfo',(req,res)=>{
	let goodsId = req.query.goodsId;
	let data = req.$goodInfoDATA.filter(item=>item.goodsId == goodsId)[0]
	res.send(success(true, {
		data:data
	}));
})


//=>删除用户信息
function del(req, res) {
	let $userDATA = req.$userDATA,
		flag = false;
	let {
		userId = 0
	} = req.query;
	$userDATA = $userDATA.map(item => {
		if (parseFloat(item.id) === parseFloat(userId)) {
			flag = true;
			return {
				...item,
				state: 1
			};
		}
		return item;
	});
	if (!flag) {
		res.send(success(false));
		return;
	}
	writeFile('./json/user.json', $userDATA).then(() => {
		res.send(success(true));
	}).catch(() => {
		res.send(success(false));
	});
}
let ary = []
route.get('/delete', (req, res) => {
	del(req, res)
});


//=>获取用户权限
route.get('/power', (req, res) => {
	res.send(success(true, {
		power: req.session.power
	}));
});

module.exports = route;